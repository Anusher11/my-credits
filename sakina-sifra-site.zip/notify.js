/* Сакина — отправка уведомлений около намазов (запускается GitHub Actions). */
const fs=require('fs');
const P=require('./praytime.js');
const PUB='BFNUJ3AilTkGK-wMpbeb5DdQkjqLV6UiyfLhRRMm0YgGS5HvfmGjIvLsy6JZ_j1gOeMcP9nR_dtG7FtMPWN3tgs';
const TZ=5; // Таджикистан, UTC+5
const SLOTS=['fajr','dhuhr','asr','maghrib','isha'];
const AFTER=5/60, WINDOW=55/60; // через 5 минут после азана, окно 50 минут

function subs(){
  const raw=(process.env.SUB||'').trim();
  if(!raw){ console.log('Секрет SAKINA_SUB пуст — добавьте код из приложения.'); return []; }
  let arr; try{ const j=JSON.parse(raw); arr=Array.isArray(j)?j:[j]; }
  catch(e){ arr=raw.split(/\n+/).map(s=>s.trim()).filter(Boolean).map(l=>JSON.parse(l)); }
  return arr;
}
function out(k,v){ if(process.env.GITHUB_OUTPUT) fs.appendFileSync(process.env.GITHUB_OUTPUT,`${k}=${v}\n`); console.log(k,'=',v); }

function plan(){
  const force=(process.env.FORCE||'').trim();
  const local=new Date(Date.now()+TZ*3600e3);
  const y=local.getUTCFullYear(), m=local.getUTCMonth()+1, d=local.getUTCDate();
  const h=local.getUTCHours()+local.getUTCMinutes()/60;
  const list=subs(); const due=[];
  list.forEach((s,i)=>{
    const c=(s&&s.c)||{lat:38.5598,lon:68.7870,n:'Душанбе'};
    const t=P.adjust(P.times(y,m,d,c.lat,c.lon,TZ),s&&s.a);
    if(force){ due.push({i,slot:SLOTS.includes(force)?force:'test'}); return; }
    for(const k of SLOTS){ const at=t[k]+AFTER; if(h>=at && h<at+WINDOW) due.push({i,slot:k}); }
    console.log((c.n||'город '+i)+':',SLOTS.map(k=>k+' '+Math.floor(t[k])+':'+String(Math.round((t[k]%1)*60)).padStart(2,'0')).join(', '));
  });
  const key=due.length?(force?'test-'+Date.now():`sent-${y}-${m}-${d}-`+due.map(x=>x.i+x.slot).join('-')):'';
  out('key',key); out('due',JSON.stringify(due));
  out('keepalive',(!force && local.getUTCDay()===5 && due.some(x=>x.slot==='fajr'))?'yes':'');
}

async function send(){
  const wp=require('web-push');
  const priv=(process.env.VAPID_PRIVATE||'').trim();
  if(!priv){ console.log('Секрет VAPID_PRIVATE пуст.'); process.exit(1); }
  const due=JSON.parse(process.env.DUE||'[]'), list=subs(); let fail=0;
  for(const x of due){
    const s=list[x.i]; const sub=s&&s.s?s.s:s;
    try{
      await wp.sendNotification(sub,JSON.stringify({slot:x.slot}),{TTL:3600,urgency:'high',vapidDetails:{subject:'https://github.com/',publicKey:PUB,privateKey:priv}});
      console.log('✓ отправлено:',x.slot,'→ телефон',x.i+1);
    }catch(e){
      fail++; console.log('✗ ошибка',e.statusCode||'',e.body||e.message);
      if(e.statusCode===404||e.statusCode===410) console.log('Подписка устарела: в приложении снова нажмите «Включить уведомления» и обновите секрет SAKINA_SUB.');
    }
  }
  if(fail) process.exit(1);
}
if(process.argv[2]==='plan') plan(); else if(process.argv[2]==='send') send();
