/* Расчёт времени намазов (алгоритм PrayTimes): Фаджр 18°, Иша 17°, Аср по ханафитскому мазхабу. */
(function(root){
  var R=Math.PI/180;
  function sin(d){return Math.sin(d*R)} function cos(d){return Math.cos(d*R)} function tan(d){return Math.tan(d*R)}
  function asin(x){return Math.asin(x)/R} function acos(x){return Math.acos(x)/R} function atan2(y,x){return Math.atan2(y,x)/R} function acot(x){return Math.atan(1/x)/R}
  function fix(a,b){a=a-b*Math.floor(a/b);return a<0?a+b:a}
  function julian(y,m,d){ if(m<=2){y-=1;m+=12} var A=Math.floor(y/100),B=2-A+Math.floor(A/4); return Math.floor(365.25*(y+4716))+Math.floor(30.6001*(m+1))+d+B-1524.5; }
  function sun(jd){ var D=jd-2451545.0, g=fix(357.529+0.98560028*D,360), q=fix(280.459+0.98564736*D,360), L=fix(q+1.915*sin(g)+0.020*sin(2*g),360), e=23.439-0.00000036*D;
    var RA=atan2(cos(e)*sin(L),cos(L))/15; return {decl:asin(sin(e)*sin(L)), eqt:q/15-fix(RA,24)}; }
  function times(y,m,d,lat,lng,tz){
    var jd=julian(y,m,d)-lng/(15*24);
    function noon(t){ return fix(12-sun(jd+t).eqt,24); }
    function angleTime(a,t,ccw){ var dc=sun(jd+t).decl, n=noon(t), T=acos((-sin(a)-sin(dc)*sin(lat))/(cos(dc)*cos(lat)))/15; return n+(ccw?-T:T); }
    function asr(f,t){ var dc=sun(jd+t).decl; return angleTime(-acot(f+tan(Math.abs(lat-dc))),t); }
    var h={fajr:angleTime(18,5/24,true), sunrise:angleTime(0.833,6/24,true), dhuhr:noon(12/24), asr:asr(2,13/24), maghrib:angleTime(0.833,18/24), isha:angleTime(17,18/24)};
    var adj=tz-lng/15; for(var k in h) h[k]=h[k]+adj;
    h.dhuhr+=2/60; h.maghrib+=2/60;
    return h; // часы (дробные), местное время
  }
  // поправки: {dhuhr:{m:'fix',v:780}} — всегда 13:00; {fajr:{m:'off',v:10}} — на 10 минут позже расчёта
  function adjust(t,a){ var r={},k; for(k in t) r[k]=t[k]; if(!a) return r;
    for(k in a){ var x=a[k]; if(!x||typeof x.v!=='number'||!(k in r)) continue; r[k]=x.m==='fix'?x.v/60:r[k]+x.v/60; } return r; }
  var api={times:times,adjust:adjust};
  if(typeof module!=='undefined'&&module.exports) module.exports=api; else root.PrayTime=api;
})(typeof self!=='undefined'?self:this);
