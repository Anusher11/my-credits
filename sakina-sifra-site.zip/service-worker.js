/* Сакина — офлайн и уведомления */
const CACHE='sakina-v3';
const CORE=['./','content.js','praytime.js','letters.js','manifest.webmanifest','icon-192.png','icon-512.png','icon-maskable-512.png','apple-touch-icon.png','badge-96.png'];
importScripts('content.js');
self.addEventListener('install',e=>{ e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())); });
self.addEventListener('activate',e=>{ e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())); });
self.addEventListener('fetch',e=>{
  const req=e.request; if(req.method!=='GET') return;
  const url=new URL(req.url);
  if(url.origin===location.origin){
    // сначала сеть (чтобы обновления приходили), без сети — из кэша
    e.respondWith(fetch(req).then(r=>{ if(r&&r.ok){ const cp=r.clone(); caches.open(CACHE).then(c=>c.put(req,cp)); } return r; })
      .catch(()=>caches.match(req,{ignoreSearch:true}).then(r=>r||(req.mode==='navigate'?caches.match('./'):undefined))));
  } else if(/fonts\.(googleapis|gstatic)\.com$/.test(url.hostname)){
    e.respondWith(caches.match(req).then(r=>r||fetch(req).then(n=>{ const cp=n.clone(); caches.open(CACHE).then(c=>c.put(req,cp)); return n; })));
  }
});
const TITLES={fajr:'🌅 Время Фаджра',dhuhr:'☀️ Время Зухра',asr:'🌤 Время Асра',maghrib:'🌇 Время Магриба',isha:'🌙 Время Иши',test:'🤍 Сакина'};
function pick(slot){
  const S=self.SAKINA, cats=S.slots[slot];
  let pool=S.items.filter(i=>i.text.length<=320&&(!cats||i.cats.some(c=>cats.includes(c))));
  if(!pool.length) pool=S.items;
  if(!cats) return pool[Math.floor(Math.random()*pool.length)];
  const day=Math.floor((Date.now()+5*3600000)/86400000), salt=Object.keys(S.slots).indexOf(slot);
  return pool[(day*3+salt*11)%pool.length];
}
function clean(t){ return t.replace(/\s*\/[^\/]{40,}\//g,'').replace(/\/([^\/]+)\//g,'$1'); }
function short(t,n){ t=clean(t); if(t.length<=n) return t; const c=t.slice(0,n); return c.slice(0,c.lastIndexOf(' '))+'…'; }
self.addEventListener('push',e=>{
  let d={}; try{ d=e.data?e.data.json():{}; }catch(_){ d={slot:e.data?e.data.text():''}; }
  if(d.type==='chat'){
    e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{
      cs.forEach(c=>c.postMessage({chat:1}));
      if(cs.some(c=>c.visibilityState==='visible'&&c.focused!==false)) return;
      return self.registration.showNotification('💬 '+(d.name||'Сообщение'),{body:String(d.text||''),icon:'icon-192.png',badge:'badge-96.png',tag:'sakina-chat',renotify:true,vibrate:[80,40,80],data:{chat:1}});
    }));
    return;
  }
  const slot=TITLES[d.slot]?d.slot:'test', it=pick(slot);
  const body=(it.intro&&it.intro.length<90?it.intro+' ':'')+short(it.text,230)+'\n— '+it.ref.replace('Коран, сура ','');
  e.waitUntil(self.registration.showNotification(TITLES[slot],{body,icon:'icon-192.png',badge:'badge-96.png',tag:'sakina-'+slot,renotify:true,vibrate:[60,40,60],data:{id:it.id}}));
});
self.addEventListener('notificationclick',e=>{
  e.notification.close(); const data=e.notification.data||{}, id=data.id, chat=!!data.chat;
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{
    for(const c of cs){ if('focus' in c){ c.postMessage(chat?{openChat:1}:{open:id}); return c.focus(); } }
    return self.clients.openWindow(chat?'./#chat':'./#item='+(id||''));
  }));
});
